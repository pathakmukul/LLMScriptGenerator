from typing import Dict, TypedDict, Annotated, Sequence, List
from langchain_core.messages import BaseMessage, FunctionMessage, HumanMessage
from langchain_openai import ChatOpenAI
from langgraph.graph import Graph, StateGraph
from langgraph.prebuilt import ToolExecutor
from langchain_core.tools import BaseTool
from pydantic import BaseModel
import operator
import json
from .types import UserRequest, AgentDefinition, ToolDefinition
import os

class AgentState(TypedDict):
    """State of the agent system."""
    messages: Annotated[Sequence[BaseMessage], operator.add]
    user_request: UserRequest
    current_tools: List[ToolDefinition]
    agent_definition: AgentDefinition | None
    next_step: str

class RequirementsAnalyzer:
    """Analyzes user requirements to determine needed tools."""
    
    def __init__(self):
        self.llm = ChatOpenAI(model="gpt-4o-mini", temperature=0)
    
    def analyze(self, state: AgentState) -> AgentState:
        """Analyze requirements and determine needed tools."""
        # Add thinking process
        thought_process = {
            "thought": "I need to analyze the user's requirements to determine what tools would be needed",
            "action": "analyze_requirements",
            "action_input": state["user_request"].description
        }
        state["messages"].append(FunctionMessage(
            name="analyze_requirements",
            content=json.dumps(thought_process)
        ))
        
        # Analyze requirements
        messages = [
            HumanMessage(content="""You are a tool analyzer. Your task is to determine what tools would be needed based on the user's requirements.
You must respond with ONLY a JSON array of tools, with no additional text or explanation.
Each tool in the array must have these fields:
- name: A short name for the tool
- description: What the tool does
- identifier: A unique identifier for the tool

Example response:
[
    {
        "name": "web_search",
        "description": "Search the web for information",
        "identifier": "web_search"
    }
]
"""),
            HumanMessage(content=f"""Request Description: {state['user_request'].description}
Requirements: {', '.join(state['user_request'].requirements)}""")
        ]
        
        try:
            response = self.llm.invoke(messages)
            tools = json.loads(response.content)
            if not isinstance(tools, list):
                raise ValueError("Response is not a JSON array")
            
            # Validate each tool has required fields
            for tool in tools:
                if not all(k in tool for k in ["name", "description", "identifier"]):
                    raise ValueError("Tool missing required fields")
            
            state["current_tools"] = [ToolDefinition(**tool) for tool in tools]
            
            # Add observation
            observation = {
                "thought": "I have identified the required tools",
                "observation": tools
            }
            state["messages"].append(FunctionMessage(
                name="analyze_requirements",
                content=json.dumps(observation)
            ))
            
        except (json.JSONDecodeError, ValueError) as e:
            # If JSON parsing fails, create a default tool set
            default_tools = [{
                "name": "web_search",
                "description": "Search the web for information",
                "identifier": "web_search"
            }]
            state["current_tools"] = [ToolDefinition(**tool) for tool in default_tools]
            
            # Add error observation
            observation = {
                "thought": "Failed to parse tool requirements, using default tools",
                "observation": {
                    "error": str(e),
                    "using_default_tools": True,
                    "default_tools": default_tools
                }
            }
            state["messages"].append(FunctionMessage(
                name="analyze_requirements",
                content=json.dumps(observation)
            ))
        
        state["next_step"] = "search_existing"
        return state

class AgentSearcher:
    """Searches for existing agents that match requirements."""
    
    def __init__(self, db_path: str = "agents.json"):
        from .db import AgentDatabase
        from .search import SemanticSearch
        self.db = AgentDatabase(db_path)
        self.searcher = SemanticSearch()
        self.llm = ChatOpenAI(model="gpt-4o-mini", temperature=0)
    
    def search(self, state: AgentState) -> AgentState:
        """Search for existing agents."""
        # Add thinking process
        thought_process = {
            "thought": "I need to search for existing agents that match these requirements",
            "action": "search_agents",
            "action_input": {
                "description": state["user_request"].description,
                "required_tools": [t.model_dump() for t in state["current_tools"]]
            }
        }
        state["messages"].append(FunctionMessage(
            name="search_agents",
            content=json.dumps(thought_process)
        ))
        
        # Get all agents
        all_agents = self.db.search_agents("")
        
        # Use semantic search with a higher threshold for stricter matching
        matching_agents = self.searcher.search(
            query=state["user_request"].description,
            agents=all_agents,
            threshold=0.85  # Increased threshold for stricter matching
        )
        
        if matching_agents:
            # Find the best matching agent
            best_agent, tool_match_score = self._find_best_tool_match(
                matching_agents,
                state["current_tools"]
            )
            
            # Only consider it a match if both semantic and tool matching scores are high
            if tool_match_score >= 0.8:  # Require 80% tool match
                state["agent_definition"] = best_agent
                
                # Add observation
                observation = {
                    "thought": "I found an existing agent that matches the requirements",
                    "observation": {
                        "agent_name": best_agent.agent_name,
                        "similarity_score": "high",
                        "tool_match_score": tool_match_score,
                        "agent_description": best_agent.agent_description
                    }
                }
                state["messages"].append(FunctionMessage(
                    name="search_agents",
                    content=json.dumps(observation)
                ))
                state["next_step"] = "end"
            else:
                # Add observation about insufficient tool match
                observation = {
                    "thought": "Found semantically similar agents but tools don't match well enough",
                    "observation": {
                        "best_tool_match_score": tool_match_score,
                        "required_tools": [t.name for t in state["current_tools"]],
                        "best_agent_tools": [t.name for t in best_agent.tools],
                        "reason": "Tool capabilities don't align sufficiently"
                    }
                }
                state["messages"].append(FunctionMessage(
                    name="search_agents",
                    content=json.dumps(observation)
                ))
                state["next_step"] = "create_agent"
        else:
            # Add observation
            observation = {
                "thought": "No existing agent matches these requirements, need to create a new one",
                "observation": {
                    "matching_agents": 0,
                    "reason": "No agents found with required capabilities"
                }
            }
            state["messages"].append(FunctionMessage(
                name="search_agents",
                content=json.dumps(observation)
            ))
            state["next_step"] = "create_agent"
        return state
    
    def _find_best_tool_match(
        self,
        agents: List[AgentDefinition],
        required_tools: List[ToolDefinition]
    ) -> tuple[AgentDefinition, float]:
        """Find the agent with the best tool compatibility.
        Returns tuple of (best_agent, match_score)."""
        required_tool_names = {t.name.lower() for t in required_tools}
        required_tool_desc = {t.description.lower() for t in required_tools}
        
        best_score = -1
        best_agent = agents[0]  # Default to first agent
        
        for agent in agents:
            agent_tool_names = {t.name.lower() for t in agent.tools}
            agent_tool_desc = {t.description.lower() for t in agent.tools}
            
            # Calculate Jaccard similarity for both names and descriptions
            name_intersection = len(required_tool_names & agent_tool_names)
            name_union = len(required_tool_names | agent_tool_names)
            name_score = name_intersection / name_union if name_union > 0 else 0
            
            desc_intersection = len(required_tool_desc & agent_tool_desc)
            desc_union = len(required_tool_desc | agent_tool_desc)
            desc_score = desc_intersection / desc_union if desc_union > 0 else 0
            
            # Combined score with more weight on description match
            score = (0.4 * name_score) + (0.6 * desc_score)
            
            if score > best_score:
                best_score = score
                best_agent = agent
        
        return best_agent, best_score

class AgentCreator:
    """Creates new agents based on requirements."""
    
    def __init__(self):
        if not os.getenv("OPENAI_API_KEY"):
            raise ValueError("OPENAI_API_KEY environment variable is not set")
        self.llm = ChatOpenAI(model="gpt-4o-mini", temperature=0)
        from .db import AgentDatabase
        self.db = AgentDatabase()
    
    def create(self, state: AgentState) -> AgentState:
        """Create a new agent."""
        try:
            # Add thinking process
            thought_process = {
                "thought": "I need to create a new ReAct agent with the specified capabilities",
                "action": "create_agent",
                "action_input": {
                    "description": state["user_request"].description,
                    "requirements": state["user_request"].requirements,
                    "tools": [t.model_dump() for t in state["current_tools"]]
                }
            }
            state["messages"].append(FunctionMessage(
                name="create_agent",
                content=json.dumps(thought_process)
            ))
            
            # Create agent prompt
            messages = [
                HumanMessage(content=f"""Create a ReAct agent system prompt for this request:
Description: {state['user_request'].description}
Requirements: {', '.join(state['user_request'].requirements)}
Available Tools: {[t.model_dump() for t in state['current_tools']]}

The prompt should follow this format:
1. Start with a clear definition of the agent's role and capabilities
2. List all available tools and their purposes
3. Explain the ReAct format (Thought, Action, Action Input, Observation)
4. Provide guidance on when to use each tool
5. Include any specific requirements or constraints

Example Format:
You are a specialized ReAct agent that [main purpose].

Available Tools:
{[f"- {t.name}: {t.description}" for t in state['current_tools']]}

Follow these steps for each task:
1. Think about what needs to be done
2. Choose the appropriate tool
3. Use the tool with proper input
4. Observe the result
5. Continue until the task is complete

When you want to use a tool, use this format:
Thought: [your reasoning]
Action: [tool name]
Action Input: [tool input]
Observation: [tool output]

When you have a final answer, respond with:
Thought: I have the answer
Final Answer: [your response]

Return ONLY the prompt text, no additional formatting or explanation.""")
            ]
            
            response = self.llm.invoke(messages)
            
            # Generate a unique agent name
            agent_name = f"agent_{len(self.db.search_agents(''))}"
            
            # Create new agent definition
            new_agent = AgentDefinition(
                agent_name=agent_name,
                agent_description=state["user_request"].description,
                agent_prompt=response.content,
                tools=state["current_tools"]
            )
            
            # Save to database
            self.db.save_agent(new_agent)
            
            # Update state
            state["agent_definition"] = new_agent
            
            # Add observation
            observation = {
                "thought": "Successfully created new agent",
                "observation": {
                    "agent_name": new_agent.agent_name,
                    "num_tools": len(new_agent.tools),
                    "prompt_length": len(new_agent.agent_prompt)
                }
            }
            state["messages"].append(FunctionMessage(
                name="create_agent",
                content=json.dumps(observation)
            ))
            
        except Exception as e:
            # Log error and add error observation
            error_observation = {
                "thought": "Failed to create agent",
                "observation": {
                    "error": str(e),
                    "error_type": type(e).__name__
                }
            }
            state["messages"].append(FunctionMessage(
                name="create_agent",
                content=json.dumps(error_observation)
            ))
            
            # Create a default agent as fallback
            default_agent = AgentDefinition(
                agent_name="default_agent",
                agent_description=state["user_request"].description,
                agent_prompt="You are a basic ReAct agent that can help with tasks.",
                tools=state["current_tools"]
            )
            state["agent_definition"] = default_agent
        
        state["next_step"] = "end"
        return state

def create_agent_graph() -> Graph:
    """Create the LangGraph workflow for agent creation/management."""
    
    # Create workflow nodes
    analyzer = RequirementsAnalyzer()
    searcher = AgentSearcher()
    creator = AgentCreator()
    
    # Create the graph
    workflow = StateGraph(AgentState)
    
    # Add nodes
    workflow.add_node("analyze_requirements", analyzer.analyze)
    workflow.add_node("search_existing", searcher.search)
    workflow.add_node("create_agent", creator.create)
    
    # Define end node
    def end_node(state: AgentState) -> AgentState:
        """End node that returns the final state."""
        # Ensure agent_definition is set
        if state["agent_definition"] is None:
            state["agent_definition"] = AgentDefinition(
                agent_name="fallback_agent",
                agent_description="A basic fallback agent",
                agent_prompt="You are a basic ReAct agent.",
                tools=state["current_tools"]
            )
        return state
    
    workflow.add_node("end", end_node)
    
    # Define conditional edges
    def route_next_step(state: AgentState) -> str:
        """Route to next step based on state."""
        return state["next_step"]
    
    # Add edges with conditions
    workflow.add_conditional_edges(
        "analyze_requirements",
        route_next_step,
        {
            "search_existing": "search_existing",
        }
    )
    
    workflow.add_conditional_edges(
        "search_existing",
        route_next_step,
        {
            "create_agent": "create_agent",
            "end": "end"
        }
    )
    
    workflow.add_conditional_edges(
        "create_agent",
        route_next_step,
        {
            "end": "end"
        }
    )
    
    # Set entry point
    workflow.set_entry_point("analyze_requirements")
    
    return workflow.compile()

class AgentiXGraph:
    """Main class for the LangGraph-based AgentiX system."""
    
    def __init__(self):
        self.graph = create_agent_graph()
    
    def process_request(self, request: UserRequest) -> AgentDefinition:
        """Process a user request and return an agent definition."""
        
        # Initialize state
        state = AgentState(
            messages=[],
            user_request=request,
            current_tools=[],
            agent_definition=None,
            next_step="analyze_requirements"
        )
        
        # Run the graph
        final_state = self.graph.invoke(state)
        return final_state["agent_definition"]
    
    def stream_process(self, state: AgentState):
        """Stream the processing of a request, showing all steps."""
        # Get the compiled graph
        graph = self.graph
        
        # Convert state to dict for streaming
        state_dict = {
            "messages": state["messages"],
            "user_request": state["user_request"],
            "current_tools": state["current_tools"],
            "agent_definition": state["agent_definition"],
            "next_step": state["next_step"]
        }
        
        # Create a fallback agent in case we need it
        fallback_agent = AgentDefinition(
            agent_name="fallback_agent",
            agent_description="A basic fallback agent",
            agent_prompt="You are a basic ReAct agent.",
            tools=state["current_tools"]
        )
        
        # Stream each step
        for chunk in graph.stream(state_dict):
            # Handle nested state structure
            if "analyze_requirements" in chunk:
                chunk = chunk["analyze_requirements"]
            elif "search_existing" in chunk:
                chunk = chunk["search_existing"]
            elif "create_agent" in chunk:
                chunk = chunk["create_agent"]
            elif "end" in chunk:
                chunk = chunk["end"]
            
            # Ensure chunk has all required keys with proper defaults
            chunk = {
                "next_step": chunk.get("next_step", state["next_step"]),
                "messages": chunk.get("messages", state["messages"]),
                "user_request": chunk.get("user_request", state["user_request"]),
                "current_tools": chunk.get("current_tools", state["current_tools"]),
                "agent_definition": chunk.get("agent_definition", state["agent_definition"])
            }
            
            # Ensure agent_definition is never None at the end
            if chunk["next_step"] == "end" and chunk["agent_definition"] is None:
                chunk["agent_definition"] = fallback_agent
            
            # Convert back to proper types if needed
            if not isinstance(chunk["user_request"], UserRequest):
                chunk["user_request"] = state["user_request"]
            
            yield chunk 