from typing import List, Dict
from langchain_openai import OpenAIEmbeddings
import numpy as np
from .types import AgentDefinition
import os

class SemanticSearch:
    """Semantic search for finding similar agents."""
    
    def __init__(self):
        if not os.getenv("OPENAI_API_KEY"):
            raise ValueError("OPENAI_API_KEY environment variable is not set")
        self.embeddings = OpenAIEmbeddings(
            model="text-embedding-ada-002"  # Use the correct embeddings model
        )
        self._cache: Dict[str, np.ndarray] = {}
    
    def _get_embedding(self, text: str) -> np.ndarray:
        """Get embedding for text, using cache if available."""
        if text not in self._cache:
            self._cache[text] = np.array(self.embeddings.embed_query(text))
        return self._cache[text]
    
    def _cosine_similarity(self, a: np.ndarray, b: np.ndarray) -> float:
        """Calculate cosine similarity between two vectors."""
        return np.dot(a, b) / (np.linalg.norm(a) * np.linalg.norm(b))
    
    def search(self, query: str, agents: List[AgentDefinition], threshold: float = 0.7) -> List[AgentDefinition]:
        """Search for agents similar to the query."""
        if not agents:
            return []
        
        query_embedding = self._get_embedding(query)
        
        results = []
        for agent in agents:
            # Get embedding for agent description
            agent_embedding = self._get_embedding(agent.agent_description)
            
            # Calculate similarity
            similarity = self._cosine_similarity(query_embedding, agent_embedding)
            
            if similarity >= threshold:
                results.append(agent)
        
        return sorted(
            results,
            key=lambda x: self._cosine_similarity(
                query_embedding,
                self._get_embedding(x.agent_description)
            ),
            reverse=True
        ) 