"""AgentiX - A platform for creating and managing ReAct agents."""

import os
from dotenv import load_dotenv

# Load environment variables at package initialization
load_dotenv()

# Verify OpenAI API key is set
if not os.getenv("OPENAI_API_KEY"):
    raise ValueError(
        "OPENAI_API_KEY environment variable is not set. "
        "Please set it in your .env file or environment variables."
    )

from .core import AgentiX
from .types import AgentDefinition, UserRequest, ToolDefinition
from .tools import ToolRegistry, ToolImplementation

__version__ = "0.1.0"
__all__ = [
    'AgentiX',
    'AgentDefinition',
    'UserRequest',
    'ToolDefinition',
    'ToolRegistry',
    'ToolImplementation'
] 