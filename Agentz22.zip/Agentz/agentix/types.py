from typing import List, Dict, Optional
from pydantic import BaseModel

class ToolDefinition(BaseModel):
    """Definition of a tool that can be used by an agent."""
    name: str
    description: str
    identifier: str

class UserRequest(BaseModel):
    """User request for an agent."""
    description: str
    requirements: List[str] = []

class AgentDefinition(BaseModel):
    """Definition of an agent."""
    agent_name: str
    agent_description: str
    agent_prompt: str
    tools: List[ToolDefinition]
    memory_type: str = "buffer"  # Default to buffer memory
    model_name: Optional[str] = "gpt-3.5-turbo"
    agent_chain_type: Optional[str] = "ZERO_SHOT_REACT_DESCRIPTION"

class UserRequest(BaseModel):
    """User's request for an agent."""
    description: str
    requirements: List[str] 