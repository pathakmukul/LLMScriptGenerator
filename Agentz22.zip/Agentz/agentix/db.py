import json
from typing import List, Optional
from pathlib import Path
from .types import AgentDefinition, ToolDefinition
import os

class AgentDatabase:
    """Manages the JSON database of agents."""
    
    def __init__(self, db_path: str = "agents.json"):
        self.db_path = db_path
        self._initialize_db()
    
    def _initialize_db(self) -> None:
        """Initialize the database file with proper JSON structure."""
        try:
            if os.path.exists(self.db_path):
                # Try to load existing data
                with open(self.db_path, 'r') as f:
                    json.load(f)
            else:
                # Create new database file
                self._save_data({"agents": []})
        except json.JSONDecodeError:
            # If file is corrupted, backup and create new
            if os.path.exists(self.db_path):
                backup_path = f"{self.db_path}.backup"
                os.rename(self.db_path, backup_path)
            self._save_data({"agents": []})
    
    def _load_data(self) -> dict:
        """Load data from JSON file."""
        try:
            if not os.path.exists(self.db_path):
                return {"agents": []}
            with open(self.db_path, 'r') as f:
                data = json.load(f)
                if not isinstance(data, dict) or "agents" not in data:
                    return {"agents": []}
                return data
        except json.JSONDecodeError:
            # If file is corrupted, return empty data
            return {"agents": []}
    
    def _save_data(self, data: dict) -> None:
        """Save data to JSON file."""
        # Ensure the data structure is correct
        if not isinstance(data, dict) or "agents" not in data:
            data = {"agents": []}
        
        # Create directory if it doesn't exist
        os.makedirs(os.path.dirname(self.db_path) if os.path.dirname(self.db_path) else '.', exist_ok=True)
        
        # Save with proper formatting
        with open(self.db_path, 'w') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
    
    def get_agent(self, agent_name: str) -> Optional[AgentDefinition]:
        """Retrieve an agent by name."""
        data = self._load_data()
        for agent_data in data["agents"]:
            if agent_data["agent_name"] == agent_name:
                tools = [ToolDefinition(**t) for t in agent_data["tools"]]
                return AgentDefinition(
                    agent_name=agent_data["agent_name"],
                    agent_description=agent_data["agent_description"],
                    agent_prompt=agent_data["agent_prompt"],
                    tools=tools,
                    memory_type=agent_data.get("memory_type", "buffer"),
                    model_name=agent_data.get("model_name", "gpt-3.5-turbo"),
                    agent_chain_type=agent_data.get("agent_chain_type", "ZERO_SHOT_REACT_DESCRIPTION")
                )
        return None
    
    def save_agent(self, agent: AgentDefinition) -> None:
        """Save an agent definition to the database."""
        data = self._load_data()
        
        # Convert agent to dict
        agent_dict = {
            "agent_name": agent.agent_name,
            "agent_description": agent.agent_description,
            "agent_prompt": agent.agent_prompt,
            "tools": [t.model_dump() for t in agent.tools],
            "memory_type": agent.memory_type,
            "model_name": agent.model_name,
            "agent_chain_type": agent.agent_chain_type
        }
        
        # Check if agent already exists
        for i, existing_agent in enumerate(data["agents"]):
            if existing_agent["agent_name"] == agent.agent_name:
                data["agents"][i] = agent_dict
                self._save_data(data)
                return
        
        # Add new agent
        data["agents"].append(agent_dict)
        self._save_data(data)
    
    def search_agents(self, description: str) -> List[AgentDefinition]:
        """Search for agents matching a description."""
        data = self._load_data()
        agents = []
        
        for agent_data in data["agents"]:
            try:
                tools = [ToolDefinition(**t) for t in agent_data["tools"]]
                agent = AgentDefinition(
                    agent_name=agent_data["agent_name"],
                    agent_description=agent_data["agent_description"],
                    agent_prompt=agent_data["agent_prompt"],
                    tools=tools,
                    memory_type=agent_data.get("memory_type", "buffer"),
                    model_name=agent_data.get("model_name", "gpt-3.5-turbo"),
                    agent_chain_type=agent_data.get("agent_chain_type", "ZERO_SHOT_REACT_DESCRIPTION")
                )
                agents.append(agent)
            except (KeyError, TypeError, json.JSONDecodeError):
                # Skip invalid agent data
                continue
        
        return agents
    
    def delete_agent(self, agent_name: str) -> bool:
        """Delete an agent from the database.
        
        Args:
            agent_name (str): The name of the agent to delete.
            
        Returns:
            bool: True if the agent was deleted, False if it wasn't found.
        """
        data = self._load_data()
        
        # Find the agent to delete
        for i, agent in enumerate(data["agents"]):
            if agent["agent_name"] == agent_name:
                # Remove the agent
                data["agents"].pop(i)
                self._save_data(data)
                return True
        
        return False 