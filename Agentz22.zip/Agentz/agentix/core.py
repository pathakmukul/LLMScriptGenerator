from typing import Dict, List, Optional
from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage
from .types import AgentDefinition, UserRequest, ToolDefinition
from .tools.registry import ToolRegistry
from .db import AgentDatabase

class AgentiX:
    """Main class for the AgentiX system."""
    
    def __init__(self):
        self.llm = ChatOpenAI(model="gpt-4o-mini", temperature=0)
        self.tool_registry = ToolRegistry()
        self.db = AgentDatabase()  # Add direct database access
        from .graph_agent import AgentiXGraph
        self.graph = AgentiXGraph()
    
    def get_all_agents(self) -> List[AgentDefinition]:
        """Get all available agents."""
        return self.db.search_agents("")
    
    def search_agents(self, query: str) -> List[AgentDefinition]:
        """Search for agents by name or description."""
        all_agents = self.get_all_agents()
        if not query:
            return all_agents
            
        return [
            agent for agent in all_agents
            if query.lower() in agent.agent_name.lower() or
            query.lower() in agent.agent_description.lower()
        ]
    
    def generate_tool(
        self,
        name: str,
        description: str,
        requirements: List[str]
    ) -> str:
        """Generate a new tool implementation."""
        tool = self.tool_registry.generate_tool_implementation(
            name=name,
            description=description,
            requirements=requirements
        )
        self.tool_registry.register_tool(tool)
        return tool.code
    
    def get_agent_code(self, agent_def: AgentDefinition) -> str:
        """Generate executable code for the agent."""
        # First, ensure all tools are generated and registered
        tool_codes = []
        for tool in agent_def.tools:
            existing_tool = self.tool_registry.get_tool(tool.identifier)
            if existing_tool:
                tool_codes.append(existing_tool.code)
            else:
                # Generate new tool if not found
                new_tool = self.tool_registry.generate_tool_implementation(
                    name=tool.name,
                    description=tool.description,
                    requirements=[]  # Add specific requirements if needed
                )
                self.tool_registry.register_tool(new_tool)
                tool_codes.append(new_tool.code)
        
        # Generate the agent code
        prompt = f"""Create a complete, production-ready implementation of a LangChain ReAct agent with these specifications:

Agent Name: {agent_def.agent_name}
Description: {agent_def.agent_description}
System Prompt: {agent_def.agent_prompt}

The implementation should:
1. Use the provided tool implementations
2. Include proper error handling and logging
3. Be well-documented
4. Include all necessary imports
5. Be production-ready
6. Include example usage

Available Tool Implementations:

{chr(10).join(tool_codes)}

Return ONLY the Python code without any explanation or markdown formatting."""
        
        response = self.llm.invoke([HumanMessage(content=prompt)])
        return response.content 