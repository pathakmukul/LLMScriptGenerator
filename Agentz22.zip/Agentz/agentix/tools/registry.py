from typing import Dict, List, Optional
from pydantic import BaseModel
import json
import os
from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage

class ToolImplementation(BaseModel):
    """Represents a tool's implementation."""
    name: str
    description: str
    code: str
    identifier: str
    dependencies: List[str]
    version: str

class ToolRegistry:
    """Registry for managing and generating tool implementations."""
    
    def __init__(self, storage_path: str = "tools_registry.json"):
        self.storage_path = storage_path
        self.llm = ChatOpenAI(model="gpt-4o-mini", temperature=0)
        self._load_registry()
    
    def _load_registry(self):
        """Load the tool registry from storage."""
        if os.path.exists(self.storage_path):
            with open(self.storage_path, 'r') as f:
                data = json.load(f)
                self.tools = {
                    name: ToolImplementation(**impl) 
                    for name, impl in data.items()
                }
        else:
            self.tools = {}
    
    def _save_registry(self):
        """Save the tool registry to storage."""
        with open(self.storage_path, 'w') as f:
            json.dump(
                {name: tool.model_dump() for name, tool in self.tools.items()},
                f,
                indent=2
            )
    
    def generate_tool_implementation(
        self,
        name: str,
        description: str,
        requirements: List[str]
    ) -> ToolImplementation:
        """Generate a new tool implementation using LLM."""
        prompt = f"""Create a Python implementation for a LangChain tool with these specifications:

Name: {name}
Description: {description}
Requirements:
{chr(10).join(f'- {req}' for req in requirements)}

The implementation should:
1. Inherit from langchain_core.tools.BaseTool
2. Include proper error handling
3. Be well-documented
4. Include necessary imports
5. Implement the _run method
6. Set name and description as class attributes
7. Be production-ready

Example format:
from langchain_core.tools import BaseTool

class MyTool(BaseTool):
    name = "tool_name"
    description = "tool description"
    
    def _run(self, query: str) -> str:
        # Implementation here
        pass

Return ONLY the Python code without any explanation or markdown formatting.
"""
        response = self.llm.invoke([HumanMessage(content=prompt)])
        
        # Extract dependencies from the code
        deps_prompt = f"""Given this Python code, list all external package dependencies (one per line):

{response.content}

Return ONLY the package names, one per line, nothing else."""
        
        deps_response = self.llm.invoke([HumanMessage(content=deps_prompt)])
        dependencies = [
            dep.strip() 
            for dep in deps_response.content.split('\n') 
            if dep.strip()
        ]
        
        tool = ToolImplementation(
            name=name,
            description=description,
            code=response.content,
            identifier=name.lower().replace(' ', '_'),
            dependencies=dependencies,
            version="1.0.0"
        )
        
        return tool
    
    def register_tool(self, tool: ToolImplementation) -> None:
        """Register a new tool in the registry."""
        self.tools[tool.identifier] = tool
        self._save_registry()
    
    def _validate_dependencies(self, tool: ToolImplementation) -> bool:
        """Validate that all required dependencies are installed.
        
        Args:
            tool (ToolImplementation): The tool to validate dependencies for.
            
        Returns:
            bool: True if all dependencies are available, False otherwise.
        """
        try:
            for dep in tool.dependencies:
                __import__(dep.split('[')[0].lower())
            return True
        except ImportError:
            return False

    def get_tool(self, identifier: str) -> Optional[ToolImplementation]:
        """Get a tool by its identifier.
        
        Also validates that all required dependencies are installed.
        If dependencies are missing, returns None and logs a warning.
        """
        tool = self.tools.get(identifier)
        if tool and not self._validate_dependencies(tool):
            print(f"Error loading tool {tool.name}: Missing required dependencies: {', '.join(tool.dependencies)}")
            return None
        return tool
    
    def search_tools(self, query: str) -> List[ToolImplementation]:
        """Search for tools based on name or description."""
        query = query.lower()
        return [
            tool for tool in self.tools.values()
            if query in tool.name.lower() or query in tool.description.lower()
        ]
    
    def get_tool_code(self, identifier: str) -> Optional[str]:
        """Get the implementation code for a tool."""
        tool = self.get_tool(identifier)
        return tool.code if tool else None
    
    def delete_tool(self, identifier: str) -> bool:
        """Delete a tool from the registry.
        
        Args:
            identifier (str): The identifier of the tool to delete.
            
        Returns:
            bool: True if the tool was deleted, False if it wasn't found.
        """
        if identifier in self.tools:
            del self.tools[identifier]
            self._save_registry()
            return True
        return False