# AgentiX

AgentiX is a tool for creating and managing ReAct agents using LangChain and LangGraph. It helps you create, store, and reuse agents for various tasks.

## Features

- Create ReAct agents based on natural language descriptions
- Store and manage agents in a CSV database
- Reuse existing agents for similar tasks
- Generate ready-to-use code for your agents
- Beautiful Streamlit interface

## Installation

1. Clone this repository:
```bash
git clone https://github.com/yourusername/agentix.git
cd agentix
```

2. Install dependencies:
```bash
pip install -r requirements.txt
```

3. Set up your OpenAI API key:
```bash
export OPENAI_API_KEY=your_api_key_here
```

## Usage

1. Start the Streamlit interface:
```bash
streamlit run agentix/app.py
```

2. Open your browser and go to http://localhost:8501

3. Describe what you want your agent to do and list any specific requirements

4. Click "Create/Find Agent" to get your custom agent

## Project Structure

- `agentix/`
  - `__init__.py`: Package initialization
  - `app.py`: Streamlit interface
  - `core.py`: Core AgentiX functionality
  - `db.py`: Agent database management
  - `tools.py`: Tool registry and definitions
  - `types.py`: Type definitions
- `agents.csv`: Database of agents
- `requirements.txt`: Project dependencies

## Contributing

1. Fork the repository
2. Create a new branch for your feature
3. Make your changes
4. Submit a pull request

## License

MIT License 