import streamlit as st
from agentix.core import AgentiX
from agentix.types import AgentDefinition, UserRequest, ToolDefinition
from typing import List, Optional
import json
from langchain_openai import ChatOpenAI
from langgraph.graph import Graph, StateGraph
from langchain_core.tools import BaseTool, Tool
from langchain_core.messages import BaseMessage, FunctionMessage, HumanMessage
from langchain_core.prompts import PromptTemplate
from langchain.chains import LLMChain
from typing import TypedDict, Annotated, Sequence
import operator
import os
class AgentState(TypedDict):
    """State of the agent system."""
    messages: Annotated[Sequence[BaseMessage], operator.add]
    next_step: str

def init_chat_history():
    """Initialize chat history in session state if not present."""
    if "messages" not in st.session_state:
        st.session_state.messages = []

def display_chat_message(role: str, content: str):
    """Display a chat message with appropriate styling."""
    if role == "user":
        st.chat_message("user").write(content)
    elif role == "assistant":
        st.chat_message("assistant").write(content)
    elif role == "system":
        st.chat_message("system").write(content)

def load_agent(agentix: AgentiX, agent_name: str) -> Optional[AgentDefinition]:
    """Load an agent by name."""
    agents = agentix.search_agents("")  # Get all agents
    for agent in agents:
        if agent.agent_name == agent_name:
            return agent
    return None

def get_tool_implementations(agentix: AgentiX, tool_defs: List[ToolDefinition]) -> List[Tool]:
    """Get actual tool implementations from the registry."""
    tools = []
    
    for tool_def in tool_defs:
        # Get implementation from registry
        impl = agentix.tool_registry.get_tool(tool_def.identifier)
        if impl:
            try:
                # Create a function that will execute the tool's code
                exec_globals = {
                    'Tool': Tool,
                    'BaseTool': BaseTool,
                    'ChatOpenAI': ChatOpenAI,
                    'PromptTemplate': PromptTemplate,
                    'LLMChain': LLMChain,
                    'llm': ChatOpenAI(model="gpt-4o-mini"),
                    'os': os,
                    'json': json,
                    'requests': __import__('requests'),
                    'dotenv': __import__('dotenv')
                }
                
                # Execute the tool code in our prepared environment
                exec(impl.code, exec_globals)
                
                # Look for a Tool class in the globals
                tool_class = None
                for var_name, var_value in exec_globals.items():
                    if isinstance(var_value, type) and issubclass(var_value, (Tool, BaseTool)):
                        tool_class = var_value
                        break
                
                if tool_class is None:
                    st.write(f"Warning: No Tool class found for {tool_def.identifier}")
                    continue
                
                # Initialize tool with required parameters
                tool_instance = tool_class(
                    name=tool_def.name,
                    description=tool_def.description,
                    func=tool_class._run
                )
                
                tools.append(tool_instance)
                
            except Exception as e:
                st.write(f"Error loading tool {tool_def.identifier}: {str(e)}")
                continue
        else:
            st.write(f"Tool {tool_def.identifier} not found in registry")
    
    return tools

def create_agent_graph(tools: List[Tool], system_prompt: str) -> Graph:
    """Create the LangGraph workflow for agent execution."""
    workflow = StateGraph(AgentState)
    
    # Initialize LLM
    llm = ChatOpenAI(model="gpt-4o-mini", temperature=0)
    
    def agent_node(state: AgentState) -> AgentState:
        """Process user input and generate agent response."""
        messages = state["messages"]
        if not messages:
            return state
            
        last_message = messages[-1]
        if not isinstance(last_message, HumanMessage):
            return state
            
        # Run LLM to get agent's response
        response = llm.invoke([
            HumanMessage(content=system_prompt),
            *messages
        ])
        
        state["messages"].append(response)
        state["next_step"] = "execute_tools"
        return state
    
    def tools_node(state: AgentState) -> AgentState:
        """Execute tools based on agent's response."""
        messages = state["messages"]
        if not messages:
            return state
            
        last_message = messages[-1]
        if not isinstance(last_message, BaseMessage):
            return state
            
        # Execute tools if needed
        tool_executor = ToolExecutor(tools)
        tool_response = tool_executor.invoke(last_message.content)
        
        state["messages"].append(FunctionMessage(
            name="tool_execution",
            content=json.dumps(tool_response)
        ))
        state["next_step"] = "agent"
        return state
    
    # Add nodes
    workflow.add_node("agent", agent_node)
    workflow.add_node("execute_tools", tools_node)
    
    # Add edges
    workflow.add_edge("agent", "execute_tools")
    workflow.add_edge("execute_tools", "agent")
    
    # Set entry point
    workflow.set_entry_point("agent")
    
    return workflow.compile()

def show_playground_page():
    """Show the agent playground page with chat interface."""
    st.title("🎮 Agent Playground")
    
    # Initialize AgentiX
    agentix = AgentiX()
    
    # Get all available agents
    agents = agentix.search_agents("")
    agent_names = [agent.agent_name for agent in agents]
    
    # Agent selection
    selected_agent_name = st.selectbox(
        "Select an Agent:",
        [""] + agent_names,
        index=0,
        placeholder="Choose an agent to interact with"
    )
    
    if not selected_agent_name:
        st.info("Please select an agent to begin.")
        return
    
    # Load selected agent definition
    agent_def = load_agent(agentix, selected_agent_name)
    if not agent_def:
        st.error(f"Could not load agent: {selected_agent_name}")
        return
    
    # Create or get agent instance if agent changed
    if "current_agent_name" not in st.session_state or st.session_state.current_agent_name != selected_agent_name:
        try:
            # Get tool implementations
            tools = get_tool_implementations(agentix, agent_def.tools)
            if not tools:
                st.error("No tool implementations found for this agent.")
                return
            
            # Create LangGraph agent
            st.session_state.agent_graph = create_agent_graph(
                tools=tools,
                system_prompt=agent_def.agent_prompt
            )
            st.session_state.current_agent_name = selected_agent_name
            
            # Initialize agent state
            st.session_state.agent_state = AgentState(
                messages=[],
                next_step="agent"
            )
            
        except Exception as e:
            st.error(f"Error initializing agent: {str(e)}")
            return
    
    # Display agent details in sidebar
    with st.sidebar:
        st.markdown("### Agent Details")
        st.markdown(f"**Description:** {agent_def.agent_description}")
        st.markdown("**Available Tools:**")
        for tool in agent_def.tools:
            st.markdown(f"- **{tool.name}**: {tool.description}")
    
    # Initialize chat history
    init_chat_history()
    
    # Display chat history
    for message in st.session_state.messages:
        display_chat_message(message["role"], message["content"])
    
    # Chat input
    if prompt := st.chat_input("Type your message here..."):
        # Add user message to chat
        st.session_state.messages.append({"role": "user", "content": prompt})
        display_chat_message("user", prompt)
        
        try:
            # Add user message to agent state
            st.session_state.agent_state["messages"].append(HumanMessage(content=prompt))
            
            # Execute the agent graph
            with st.spinner("Agent is thinking..."):
                # Run the graph
                final_state = st.session_state.agent_graph.invoke(st.session_state.agent_state)
                
                # Get the final response
                if final_state["messages"]:
                    response = final_state["messages"][-1].content
                    
                    # Update chat history
                    st.session_state.messages.append({"role": "assistant", "content": response})
                    display_chat_message("assistant", response)
                    
                    # Update agent state
                    st.session_state.agent_state = final_state
            
        except Exception as e:
            error_msg = f"Error executing agent: {str(e)}"
            st.session_state.messages.append({"role": "system", "content": error_msg})
            display_chat_message("system", error_msg)
    
    # Add clear chat button
    if st.button("Clear Chat"):
        st.session_state.messages = []
        st.session_state.agent_state = AgentState(
            messages=[],
            next_step="agent"
        )
        st.rerun()